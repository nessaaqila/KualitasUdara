<?php 
$conn = mysqli_connect('localhost', 'kual2865_admin', 'Desember26.', 'kual2865_userdb');

?>